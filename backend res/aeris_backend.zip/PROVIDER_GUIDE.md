# Provider Guide — plugging your AI model into the base backend

## Contract (implement exactly this)
```python
class MyModel:
    name = "my-model"            # unique id, used in ?provider=my-model
    version = "1.0.0"
    description = "..."
    def ready(self, store) -> bool: ...      # e.g. check artifacts exist
    def forecast(self, store, location_id: str, pollutants: list[str], horizon: int):
        return [ForecastPoint(timestamp=..., pollutant="pm25",
                              predicted=..., lower=..., upper=...), ...]
```
`store` gives you history: `store.observations(location_id, pollutant, limit)` -> DataFrame.

## Register (2 lines in base_backend.py or your own module imported at startup)
```python
from base_backend import REGISTRY
REGISTRY.register(MyModel())
```

## Rules (hackathon-critical)
1. Never fabricate API responses — raise on missing data.
2. Return prediction intervals (`lower`/`upper`) — conformal or quantile based.
3. Keep `source` honest; if your training data is placeholder, say so.
4. Your model must beat `baseline` (persistence+diurnal) on the same chronological split before claiming superiority.

## What you get for free
Endpoints `/v1/forecast/*`, AQI (CPCB), events, recommendations, explanations,
CORS, optional API-key auth on POST routes, artifact hot-reload (`POST /v1/admin/reload`).
